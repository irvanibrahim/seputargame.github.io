<html><head>
      <title>Home</title>
<link rel="icon" href="logo1.jpg">
</head>
<body background="backstop.png">
      <center><img src="bgawal.jpg" width="1000" height="400"><table width="1000" height="400" border="0" background="black.png" cellpadding="0" cellspacing="<tr>
<td colspan=" 2"="" color="black" align="center">



<tbody><tr height="50"><td colspan="2" background="nd.jpg" align="left" height="20">
<p></p><ul><ul><left><blink><b><font color="white" size="5"><font face="Century Gothic"><img src="gif.gif" border="0" width="60" height="60">The Last of Us Part 2 <img src="gif.gif" border="0" width="60" height="60"></font></font></b></blink></left></ul></ul><p></p>
<center>      <ul><a href="uts_irvanibrahim.html" title="ke Rumah"><img src="home.png" border="0" width="55" height="50"></a>
<a href="https://www.instagram.com/naughty_dog_inc/?hl=id" target="_blank" title="Instagram"><img src="ig.png" border="0" width="45" height="45"></a>
<a href="https://www.youtube.com/watch?v=qPNiIeKMHyg" target="_blank" title="YouTube"><img src="yt.png" border="0" width="50" height="50"></a>

</ul></center>
</td>
</tr>
<tr>
<td width="796" height="700" background="white" valign="top">
<p><font color="white" size="5"><font face="Century Gothic"><b>Rangkuman Cerita Akhir The Last of Us 2</b></font></font>
</p><p align="lift"><font color="white"><font face="Century Gothic"><justify>Setelah Abby meninggalkan Ellie yang sekarat dalam pertarungan mereka di Seattle, Ellie kemudian berhasil kembali ke rumah dan memulai sebuah hidup yang baru bersama Dina. Setting waktu kemudian berjalan menuju 18 bulan kemudian, dimana para pemain diperlihatkan jika Ellie dan Dina memiliki seorang anak yang bernama JJ (nama yang kemungkinan digunakan untuk menghormati Joel dan Jesse). Mereka tinggal di sebuah peternakan yang tidak jauh dari wilayah Jackson.
Semuanya nampak bahagia dan normal untuk Ellie, sampai kemudian diketahui bahwa Ellie masih menderita trauma berat akibat peristiwa pembunuhan Joel. Ellie tidak mampu mencari cara untuk menghilangkan trauma tersebut selain dengan menghabisi nyawa Abby dengan tangannya sendiri. Kunjungan Tommy ke rumah Ellie, yang kemudian mengabarkan dimana lokasi dan posisi dari Abby dan Lev berada, menjadi memicu Ellie untuk kembali berpetualang memburu Abby meskipun Dina tidak setuju. <br>
<br>
Di sisi lain, Abby dan Lev berhasil menemukan keberadaan Fireflies yang kembali dibangun yang berada di Santa Barbara. Tapi, di tengah perjalanan mereka disergap oleh kelompok tentara bayaran bernama The Rattlers. Beberapa bulan kemudian, Ellie akhirnya tiba di sebuah tempat yang ternyata adalah markas Rattler. Disana Ellie kemudian menemukan Abby dan Lev yang berusaha untuk kabur, Ellie sempat berpikir untuk mennyelamatkan mereka tapi bayangan Joel muncul yang akhirnya membuat Ellie tidak jadi membantunya.
<br><br>  

<br> Keduanya kemudian bertarung dan Ellie berhasil menang atas Abby dan dia hampir saja membuat Abby terbunuh, sampai kemudian dia kembali teringat akan wajah Joel. Akhirnya Ellie membiarkan Abby pergi bersama Lev dengan menggunakan sebuah kapal. Ellie kemudian kembali pulang dan dia melihat bahwa rumahnya sudah dalam keadaan kosong, selain bagian studio dan lukisannya. Dia kemudian mengambil gitar dan memainkannya sambil muncul kembali ingatan tentang pertarungannya dengan Abby.<br>
<br>Satu malam sebelum kematian Joel, Ellie sempat mengunjungi rumah Joel dan berbicara dengannya karena terus menggangu hidupnya setelah dia memutuskan untuk pergi, setelah mengetahui apa yang sebenarnya terjadi dengan Fireflies bertahun-tahun yang lalu. Setelah ingatan tentang Joel selesai, Ellie kemudian menyimpan kembali gitarnya dan kamera kemudian bergeser ke arah luar yang memperlihatkan Ellie kembali ke dunia luar.  
<p><font color="white" size="4"><font face="Century Gothic"><b>Penjelasannya</b></font></font>
<br>Jadi, apa maksud semua itu? Meskipun Geeks dan para fans lainnya memiliki asumsi sendiri, tapi berikut adalah garis besarnya. Di sepanjang game, para pemain diarahkan untuk percaya bahwa pertemuan terakhir Ellie dengan Joel sebelum kematiannya merupakan sebuah konfrontasi, dimana Ellie marah karena Joel menolak untuk menerima bahwa pertemanan diantara mereka sudah selesai.Sejauh yang kita ketahui, Ellie belum memaafkan apa yang dilakukan oleh Joel di game pertamanya, yang mana hal itu menjelaskan mengapa Ellie begitu bernafsu untuk membalas dendam kepada Abby.<br>
 Jauh di lubuk hatinya, Ellie marah pada dirinya sendiri karena dia tidak meluruskan semua masalah yang terjadi antara dirinya dan Joel, yang merupakan sosok ayah bagi Ellie, sebelum semuanya terlambat. Di sisi lain, dalam adegan flashback terakhir tersebut mengungkapkan bahwa Joel tidak begitu khawatir bahwa dia akan kehilangan Ellie untuk selamanya. Justru, Ellie memilih untuk memulai proses memaafkan Joel, sebelum Ellie dan WLF mengambil semua kesempatan tersebut.<br>
 Hal itu juga semakin mempertegas dan membuat para fans paham bagaimana Ellie begitu membenci sosok Abby. Ellie juga kemudian diberikan pilihan sulit pada masa sekarang, ketika Ellie akan membuat Abby mati tenggelam dan kemudian memori Joel kembali muncul. Hal itu mengingatkan Ellie bahwa dia mampu memberikan ampunan. Dia bisa menghormati kenangan tentang temannya dengan jauh lebih baik darinya, yaitu dengan mengampuni orang yang sudah membunuh rekannya. Hal ini bisa menjadi tanda bahwa Ellie sudah melampaui masa berat dan masa trauma dalam hidupnya, dan Ellie mulai melangkah dengan kehidupan yang baru.<br>
 <br><br>
</justify></font></font></p><font color="yellow">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div style="clear: both;"></div>

<font="left" form="" method="post" action="file:///C:/Users/COMPAQ/Documents/HTML.1/new%204.html">
<input type="hidden" name="friendID" value="123456">
<textarea name="f_comments" cols="40" rows="5" "="">Enter your comments here...
</textarea><br>
<input type="submit" value="coments">
<input type="reset" value="exit">

</font="left"></font></td>
<td width="50" height="700" bgcolor="" valign="top">
<table align="left" width="200" border="0" bgcolor="" bordercolor="green">
<tbody><tr>
<td><p><a href="https://www.youtube.com/watch?v=X0VubwgS2Y4" target="_blank" title="Trailer thelastofus2 tommy"> <img src="thls tommy link ytb.jpg" border="0" width="90" height="70"></a></p></td>
</tr><tr>
<td><p><a href="https://www.youtube.com/watch?v=zdkmWigbq9Y" target="_blank" title="trailer paris game week 2017"> <img src="link 2 ytb  tr.jpg" border="0" width="90" height="70"></a></p></td><td>
</td></tr>
<tr>
<td><p><a href="https://www.youtube.com/watch?v=II5UsqP2JAk " target="_blank" title="release date reveal the the last of us"> <img src="ytb tr 3.jpg" border="0" width="90" height="70"></a></p></td><td>
</td></tr>
<tr>
<td><p><a href="https://www.youtube.com/watch?v=TXl9GI1p_Os" target="_blank" title="The Last of Us Part II – Official Extended Commercial | PS4"> <img src="ytb tr 4.jpg" border="0" width="90" height="70"></a></p></td><td>
</td></tr>
<tr>
<td><p><a href="https://www.youtube.com/watch?v=pMW_sycSs30" target="_blank" title="The Last of Us Part 2 Gameplay Trailer (4K) - E3 2018"> <img src="ytb tr5.jpg" border="0" width="90" height="70"></a></p></td><td>
<p></p>
</td></tr>
</tbody></table>


<center>
</center><table align="left" width="200" border="0" bgcolor="" bordercolor="black">                            
<tbody><tr><td width="200" valign="top"><font color="white" face="Century Gothic">
<b>INFO Lebih Lanjut </b>
<ul>
<li><a href="https://id.wikipedia.org/wiki/The_Last_of_Us_Part_II" target="_blank" title="The last of us "><font color="white" face="Century Gothic">The last Of us 2</font></a></li>
<html>
<head>
    <title>Contact Us</title>
</head>
<body>
    <form action="contact.php" method="POST">
        <fieldset>
        <legend>Contact</legend>
        <p>
            <label>Name:</label>
            <input type="text" name="name" placeholder="your name..." />
        </p>
        <p>
            <label>Subject:</label>
            <input type="text" name="subject" placeholder="subject..." />
        </p>
        <p>
            <label>Email:</label>
            <input type="email" name="email" placeholder="your email..." />
        </p>
        <p>
            <input type="submit" name="submit" value="Send" />
        </p>
        </fieldset>
    </form>
</body>
</html>
<li><a href="index.php" target="_blank" title="The last of us "><font color="white" face="Century Gothic">GO Back</font></a></li>

</ul></font></td></tr></tbody></table></td>
</tr>
<tr height="50">
<td colspan="2" background="logi1.jpg"><center><b><marquee><font face="Broadway" color="black" size="7">Thank YOuu</font></marquee></b></center></td></tr>
</tbody></table><div style="position: fixed; bottom: 0px; left: 10px;width:130px;height:160px;">

</div></center></body></html>