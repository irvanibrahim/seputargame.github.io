<?php
	$conn = mysqli_connect('localhost','root','','belajar');
	if(!$conn){
		echo 'berhasil terhubung ke database';
	}
?>	